import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import '../static/index.css';
import '../static/base.css';

ReactDOM.render(<App />, document.getElementById('app'));
